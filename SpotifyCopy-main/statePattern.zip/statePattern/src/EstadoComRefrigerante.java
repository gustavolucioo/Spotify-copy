public class EstadoComRefrigerante implements MaquinaRefrigeranteEstado {

    private MaquinaRefrigerante maquinaRefrigerante;

    public EstadoComRefrigerante(MaquinaRefrigerante maquinaRefrigerante) {
        this.maquinaRefrigerante = maquinaRefrigerante;
    }

    private void removerRefrigerante() {
        maquinaRefrigerante.reduzirUmRefrigerante();

        if (maquinaRefrigerante.getQuantiaRefrigerantes() == 0) {
            maquinaRefrigerante.setEstadoAtual(maquinaRefrigerante.getEstadoSemRefrigerante());
        }
    }

    @Override
    public void pegarCoca() {
        System.out.println("hmmmm coquinha gelada :P");
        removerRefrigerante();
    }

    @Override
    public void pegarPepsi() {
        System.out.println("hmmmm pesi gelada :P");
        removerRefrigerante();
    }
}