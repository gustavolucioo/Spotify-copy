public interface MaquinaRefrigeranteEstado {
    public void pegarCoca();
    public void pegarPepsi();
}