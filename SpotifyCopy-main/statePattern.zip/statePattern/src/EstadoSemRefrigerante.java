public class EstadoSemRefrigerante implements MaquinaRefrigeranteEstado {

    private MaquinaRefrigerante _maquinaRefrigerante;

    public EstadoSemRefrigerante(MaquinaRefrigerante _maquinaRefrigerante) {
//            this.maquinaRefrigerante = _maquinaRefrigerante;
    }

    @Override
    public void pegarCoca() {
        System.out.println("sem coquinha gelada :(");
    }

    @Override
    public void pegarPepsi() {
        System.out.println("sem bepsi :(");
    }
}