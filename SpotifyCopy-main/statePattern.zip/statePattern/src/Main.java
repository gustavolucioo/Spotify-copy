public class Main {
    public static void main(String[] args) {
        MaquinaRefrigerante mr = new MaquinaRefrigerante(5);
        mr.consumirPepsi();
        mr.consumirPepsi();
        mr.consumirCoca();
        mr.consumirCoca();
        mr.consumirCoca();

        mr.consumirCoca();
        mr.consumirPepsi();
    }
}
