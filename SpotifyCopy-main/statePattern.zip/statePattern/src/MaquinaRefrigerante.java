public class MaquinaRefrigerante {

    private MaquinaRefrigeranteEstado estadoAtual;
    public EstadoSemRefrigerante estadoSemRefrigerante;
    public EstadoComRefrigerante estadoComRefrigerante;

    public MaquinaRefrigerante(int quantiaRefrigerantes) {
        this.estadoSemRefrigerante = new EstadoSemRefrigerante(this);
        this.estadoComRefrigerante = new EstadoComRefrigerante(this);

        this.quantiaRefrigerantes = quantiaRefrigerantes;

        if (quantiaRefrigerantes <= 0) {
            this.estadoAtual = this.estadoSemRefrigerante;
            return;
        }

        this.estadoAtual = this.estadoComRefrigerante;
    }

    public EstadoComRefrigerante getEstadoComRefrigerante() {
        return estadoComRefrigerante;
    }

    public EstadoSemRefrigerante getEstadoSemRefrigerante() {
        return estadoSemRefrigerante;
    }

    public void setEstadoAtual(MaquinaRefrigeranteEstado estadoAtual) {
        this.estadoAtual = estadoAtual;
    }

    private int quantiaRefrigerantes;

    public int getQuantiaRefrigerantes() {
        return quantiaRefrigerantes;
    }

    public void consumirCoca() {
        this.estadoAtual.pegarCoca();
    }

    public void consumirPepsi() {
        this.estadoAtual.pegarPepsi();
    }

    public void reduzirUmRefrigerante() {
        this.quantiaRefrigerantes--;
    }
}